

<?php $__env->startSection('content'); ?>

        <div class="container-fluid">
          <div class="animated fadeIn">
            <div class="row">
              <div class="col-sm-12 col-md-10 col-lg-8 col-xl-6">
                <div class="card">
                    <div class="card-header">
                      <i class="fa fa-align-justify"></i> <?php echo e(__('Edit')); ?>: <?php echo e($note->title); ?></div>
                    <div class="card-body">
                        <form method="POST" action="/notes/<?php echo e($note->id); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group row">
                                <div class="col">
                                    <label>Title</label>
                                    <input class="form-control" type="text" placeholder="<?php echo e(__('Title')); ?>" name="title" value="<?php echo e($note->title); ?>" required autofocus>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col">
                                    <label>Content</label>
                                    <textarea class="form-control" id="textarea-input" name="content" rows="9" placeholder="<?php echo e(__('Content..')); ?>" required><?php echo e($note->content); ?></textarea>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col">
                                    <label>Applies to date</label>
                                    <input type="date" class="form-control" name="applies_to_date" value="<?php echo e($note->applies_to_date); ?>" required/>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col">
                                    <label>Status</label>
                                    <select class="form-control" name="status_id">
                                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $status->id == $note->status_id ): ?>
                                                <option value="<?php echo e($status->id); ?>" selected="true"><?php echo e($status->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col">
                                    <label>Note type</label>
                                    <input class="form-control" type="text" placeholder="<?php echo e(__('Note type')); ?>" name="note_type" value="<?php echo e($note->note_type); ?>" required>
                                </div>
                            </div>
 
                            <button class="btn btn-block btn-success" type="submit"><?php echo e(__('Save')); ?></button>
                            <a href="<?php echo e(route('notes.index')); ?>" class="btn btn-block btn-primary"><?php echo e(__('Return')); ?></a> 
                        </form>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\April 2021\coreui\resources\views/dashboard/notes/edit.blade.php ENDPATH**/ ?>