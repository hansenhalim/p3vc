

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="container-fluid">
  <div class="fade-in">
    <div class="row">
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header"><h4>Show BREAD "<?php echo e($form->name); ?>"</h4></div>
            <div class="card-body">           
                <div class="row">
                    <div class="col-6">
                            <a 
                                href="<?php echo e(route('bread.index')); ?>"
                                class="btn btn-primary mb-3"
                            >
                                Return
                            </a>
                        <table class="table">
                          <tr>
                            <td>
                                Form name
                            </td>
                            <td>
                                <?php echo e($form->name); ?>

                            </td>
                          </tr>
                          <tr>
                            <td>
                                Database table name
                            </td>
                            <td>
                                <?php echo e($form->table_name); ?>

                            </td>
                          </tr>
                          <tr>
                            <td>
                                Records on one page of table
                            </td>
                            <td>
                                <?php echo e($form->pagination); ?>

                            </td>
                          </tr>
                          <tr>
                            <td>
                              Enable Show button in table
                            </td>
                            <td>
                                <?php echo e($form->read); ?>

                            </td>
                          </tr>
                          <tr>
                            <td>
                              Enable Edit button in table
                            </td>
                            <td>
                              <?php echo e($form->edit); ?>

                            </td>
                          </tr>
                          <tr>
                            <td>
                              Enable Add button in table
                            </td>
                            <td>
                              <?php echo e($form->add); ?>

                            </td>
                          </tr>
                          <tr>
                            <td>
                              Enable Delete button in table
                            </td>
                            <td>
                              <?php echo e($form->delete); ?>

                            </td>
                          </tr>
                        </table>
                        <?php $__currentLoopData = $formFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card bg-light mb-3">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($field->name); ?></h5>
                                    <p>Field type:  <strong><?php echo e($field->type); ?></strong></p>
                                    <p>Optional relation table name: <strong><?php echo e($field->relation_table); ?></strong></p>
                                    <p>Optional column name to print in relation table: <strong><?php echo e($field->relation_column); ?></strong></p>
                                    <p>Browse:      <?php echo e($field->browse); ?></p>
                                    <p>Read:        <?php echo e($field->read); ?></p>
                                    <p>Edit:        <?php echo e($field->edit); ?></p>
                                    <p>Add:         <?php echo e($field->add); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <a 
                                href="<?php echo e(route('bread.index')); ?>"
                                class="btn btn-primary"
                            >
                                Return
                            </a>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\April 2021\coreui\resources\views/dashboard/form/show.blade.php ENDPATH**/ ?>